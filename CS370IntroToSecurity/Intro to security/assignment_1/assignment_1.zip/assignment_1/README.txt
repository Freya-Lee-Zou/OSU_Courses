Hint: Before running any program, please ensure that the "words.txt" file is located in the directory. This is because, for section 3.2, the program reads English words from the "words.txt" file. If the text file is missing, section 3.2 will not function properly. 

=======================COMMANDS==============================

-TO RUN 3.2.py please use the command: python3 3.2.py
-TO RUN 3.3.py please use the command: python3 3.3.py

===============================================================


******************IMPORTANT MESSAGES***************************
Regarding part 3.3, the program runs rather slowly, taking approximately 10 minutes to complete. I've put in my best efforts to optimize it, but despite these efforts, it still takes around 10 minutes to finish running. So, I kindly request your patience.